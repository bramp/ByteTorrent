BTChange 0.95 (bytetorrent.sf.net) - by bramp (me@bramp.net)

BTChange allows you to change the tracker URL in a batch of torrent
files very easily and quickly without effecting the torrent's hash.
The app is written in C++, and actually decodes the torrent data 
into objects, instead of being a simple find and replace tool ;)
I soon hope to release more torrent apps and all of the source once 
I tidy it up and finish my other programs. If anyone has any 
suggestions for other programs or you find bugs in this one then 
just email me. Thanks.

-------------------------------------------------------------------

Usage: btchange [-f find] [-r replace] [/?] [files]
      -f find     Finds all torrents using this tracker
      -r replace  Replaces all matched trackers with this

Example:  btchange -f roop -r http://newurl:6969/announce
This will find all trackers with the word roop in and replace
the entire tracker string with the new url in all *.torrents

Example:  btchange A*.torrent
Shows info for all torrents begining with A

Please use with care. You could accidently ruin all your torrents
                                               (bytetorrent.sf.net)

-------------------------------------------------------------------